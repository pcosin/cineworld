const peliculasDesarrollo = [
  {
    id: 1,
    title: "Una semana en Madrid",
    img: "/assets/images/una-semana-en-madrid/una-semana-en-madrid.webp",
    description: "",
    route: "una-semana-en-madrid.html",
  },
  {
    id: 2,
    title: "Mudanza internacional",
    img: "/assets/images/mundanza-internacional/mundanza-internacional.webp",
    description: "",
    route: "mundanza-internacional.html",
  },
  {
    id: 3,
    title: "Noches blancas",
    img: "/assets/images/noches-blancas/noches-blancas.webp",
    description: "",
    route: "noches-blancas.html",
  },
  {
    id: 4,
    title: "Las tres vidas de Carlos Slepoy",
    img: "/assets/images/carlos/carlos.webp",
    description: "carlos.html",
  },
];
