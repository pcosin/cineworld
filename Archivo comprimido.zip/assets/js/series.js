const series = [
  {
    id: 1,
    title: "Mythos",
    img: "/assets/images/mythos/mythos.webp",
    description: "",
    route: "mythos.html",
  },
  {
    id: 2,
    title: "Impresos",
    img: "/assets/images/impresos/impresos.webp",
    route: "impresos.html",
  },
];
