const videoClips = [
  {
    id: 1,
    title: "Solo por hoy",
    img: "/assets/images/solo-por-hoy/solo-por-hoy.jpg",
    route: "https://www.youtube.com/watch?v=YrR6oweD7vk",
  },
  {
    id: 2,
    title: "Te veo pasar",
    img: "/assets/images/te-veo-pasar/te-veo-pasar.webp",
    route: "https://www.youtube.com/watch?v=fSy8QQ7glp4&start_radio=1&list=RDfSy8QQ7glp4",
  },
  {
    id: 3,
    title: "Ni siquiera entre tus brazos",
    img: "/assets/images/ni-siquiera-en-tus-brazos/ni-siquiera-en-tus-brazos.webp",
    route: "https://www.youtube.com/watch?v=9w3Ma9hcj9k",
  },
];
